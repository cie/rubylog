class Object
  include Rubylog::Term
  include Rubylog::Unifiable
  include Rubylog::DSL::FirstOrderFunctors
end
