module Rubylog
  module Term
    #def rubylog_compile_variables vars=[], vars_by_name={}
    def rubylog_compile_variables *_
      self
    end

    def rubylog_variables
      []
    end

  end



end
