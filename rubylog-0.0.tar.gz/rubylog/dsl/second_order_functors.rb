module Rubylog
  module DSL
    module SecondOrderFunctors
      # see rubylog/builtins.rb
    end
  end
end
      
