module Rubylog
  module DSL
    module FirstOrderFunctors
      # see rubylog/builtins.rb
    end
  end
end
      

