require "rubylog"

Rubylog.use :variables, :implicit_predicates, String, Numeric

4.queens!

0.queens! []
N.queens


