class Proc
  include Rubylog::ProcMethodAdditions
end
