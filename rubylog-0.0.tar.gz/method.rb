class Method
  include Rubylog::ProcMethodAdditions
end
