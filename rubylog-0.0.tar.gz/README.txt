Rubylog -- Prolog for Ruby
**************************




